package carrier

import (
	"errors"
	"log/slog"
	"math"
	"os"
	"strconv"

	quic "github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/congestion"
	hycc "proto-x/internal/hycc"
)

// These process-wide switches are intentionally confined to the research
// worktree. Stable configuration, scheduler and session semantics are unchanged.
type ccOptions struct {
	mode                    string
	profile                 string
	bytesPerSecond          uint64
	disableLossCompensation bool
}

func ccOptionsFromEnv() (*ccOptions, error) {
	o := &ccOptions{mode: os.Getenv("PROTOX_CC")}
	switch o.mode {
	case "", "reno":
		o.mode = "reno"
	case "hy-bbr-standard":
		o.profile = "standard"
	case "hy-bbr-conservative":
		o.profile = "conservative"
	case "hy-bbr-aggressive":
		o.profile = "aggressive"
	case "hy-brutal":
		rate, err := strconv.ParseFloat(os.Getenv("PROTOX_CC_BRUTAL_MBPS"), 64)
		if err != nil || math.IsNaN(rate) || math.IsInf(rate, 0) || rate <= 0 || rate > 100000 {
			return nil, errors.New("experimental Brutal requires PROTOX_CC_BRUTAL_MBPS in (0, 100000]")
		}
		o.bytesPerSecond = uint64(rate * 1e6 / 8)
		if o.bytesPerSecond == 0 {
			return nil, errors.New("experimental Brutal rate is below one byte per second")
		}
		if value := os.Getenv("PROTOX_CC_DISABLE_LOSS_COMPENSATION"); value != "" {
			o.disableLossCompensation, err = strconv.ParseBool(value)
			if err != nil {
				return nil, errors.New("PROTOX_CC_DISABLE_LOSS_COMPENSATION must be boolean")
			}
		}
	default:
		return nil, errors.New("PROTOX_CC must be reno, hy-bbr-standard, hy-bbr-conservative, hy-bbr-aggressive, or hy-brutal")
	}
	return o, nil
}

// Start calls install only after the PROTO-X application authentication has
// completed. Hysteria likewise replaces its controller after authentication.
func (o *ccOptions) install(conn *quic.Conn) error {
	var factory congestion.Factory
	switch {
	case o.mode == "hy-brutal":
		factory = hycc.BrutalFactory(o.bytesPerSecond, o.disableLossCompensation)
	case o.profile != "":
		var err error
		factory, err = hycc.BBRFactory(o.profile)
		if err != nil {
			return err
		}
	}
	if factory != nil {
		generation := 0 // all accesses are on this Conn's event loop
		if err := conn.SetCongestionControlFactory(func(size congestion.ByteCount) (congestion.CongestionControl, error) {
			cc, err := factory(size)
			if err == nil {
				generation++
				slog.Info("experimental QUIC controller created", "controller", o.mode,
					"generation", generation, "max_datagram_size", size, "quic_base", "v0.65.0")
			}
			return cc, err
		}); err != nil {
			return err
		}
	}
	slog.Info("experimental QUIC controller installed", "controller", o.mode,
		"quic_base", "v0.65.0",
		"hysteria_source", "ca8fbd874fd6ca82413948de6dc5924405e103e1",
		"brutal_bytes_per_second", o.bytesPerSecond,
		"disable_loss_compensation", o.disableLossCompensation)
	return nil
}
