package carrier

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"io"
	"math/big"
	"net"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	quic "github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/congestion"
	"github.com/stretchr/testify/require"
	hycc "proto-x/internal/hycc"
)

type ccPair struct {
	ctx            context.Context
	client, server *quic.Conn
	first, second  *quic.Transport
}

func newCCPair(t *testing.T) ccPair {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	t.Cleanup(cancel)
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	template := &x509.Certificate{SerialNumber: big.NewInt(1), NotBefore: time.Now().Add(-time.Minute), NotAfter: time.Now().Add(time.Hour), DNSNames: []string{"localhost"}}
	der, err := x509.CreateCertificate(rand.Reader, template, template, pub, priv)
	require.NoError(t, err)
	ln, err := quic.ListenAddr("127.0.0.1:0", TLSConfig(tls.Certificate{Certificate: [][]byte{der}, PrivateKey: priv}), QUICConfig())
	require.NoError(t, err)
	t.Cleanup(func() { _ = ln.Close() })
	transport := func() *quic.Transport {
		u, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1)})
		require.NoError(t, err)
		tr := &quic.Transport{Conn: u}
		t.Cleanup(func() { _ = tr.Close(); _ = u.Close() })
		return tr
	}
	tr1, tr2 := transport(), transport()
	c, err := tr1.Dial(ctx, ln.Addr(), &tls.Config{MinVersion: tls.VersionTLS13, InsecureSkipVerify: true, NextProtos: []string{ALPN}}, QUICConfig())
	require.NoError(t, err)
	t.Cleanup(func() { _ = c.CloseWithError(0, "test complete") })
	s, err := ln.Accept(ctx)
	require.NoError(t, err)
	t.Cleanup(func() { _ = s.CloseWithError(0, "test complete") })
	return ccPair{ctx: ctx, client: c, server: s, first: tr1, second: tr2}
}

func ccFactoryForTest(t *testing.T, mode string) congestion.Factory {
	t.Helper()
	if mode == "brutal" {
		return hycc.BrutalFactory(750000, false)
	}
	factory, err := hycc.BBRFactory(mode)
	require.NoError(t, err)
	return factory
}

func installCounted(t *testing.T, conn *quic.Conn, factory congestion.Factory, count *atomic.Int64) {
	t.Helper()
	require.NoError(t, conn.SetCongestionControlFactory(func(size congestion.ByteCount) (congestion.CongestionControl, error) {
		cc, err := factory(size)
		if err == nil {
			count.Add(1)
		}
		return cc, err
	}))
}

// startCCEcho returns one original bidirectional stream. All phases below use
// that same stream while only QUIC's native path changes.
func startCCEcho(t *testing.T, p ccPair) (*quic.Stream, <-chan error) {
	t.Helper()
	finished := make(chan error, 1)
	go func() {
		s, err := p.server.AcceptStream(p.ctx)
		if err != nil {
			finished <- err
			return
		}
		_, err = io.Copy(s, s)
		if closeErr := s.Close(); err == nil {
			err = closeErr
		}
		finished <- err
	}()
	s, err := p.client.OpenStreamSync(p.ctx)
	require.NoError(t, err)
	require.NoError(t, s.SetDeadline(time.Now().Add(15*time.Second)))
	return s, finished
}

func exchangeCC(t *testing.T, s *quic.Stream, phase, size int) {
	t.Helper()
	payload := make([]byte, size)
	for i := range payload {
		payload[i] = byte((i*71 + i/113 + phase*19) % 251)
	}
	written := make(chan error, 1)
	go func() { _, err := s.Write(payload); written <- err }()
	got := make([]byte, len(payload))
	_, err := io.ReadFull(s, got)
	require.NoError(t, err)
	require.Equal(t, payload, got, "path changes must preserve ordered bytes exactly")
	require.NoError(t, <-written)
}

func TestCC65NativeMigrationRetainsControllerAndOriginalStream(t *testing.T) {
	for _, mode := range []string{"reno", "standard", "conservative", "aggressive", "brutal"} {
		t.Run(mode, func(t *testing.T) {
			p := newCCPair(t)
			var clients, servers atomic.Int64
			if mode != "reno" {
				factory := ccFactoryForTest(t, mode)
				installCounted(t, p.client, factory, &clients)
				installCounted(t, p.server, factory, &servers)
			}
			s, finished := startCCEcho(t, p)
			exchangeCC(t, s, 0, 256<<10)
			for round, tr := range []*quic.Transport{p.second, p.first} {
				path, err := p.client.AddPath(tr)
				require.NoError(t, err)
				require.NoError(t, path.Probe(p.ctx))
				require.NoError(t, path.Switch())
				exchangeCC(t, s, round+1, 256<<10)
				require.Eventually(t, func() bool {
					return p.client.LocalAddr().String() == tr.Conn.LocalAddr().String() && p.server.RemoteAddr().String() == tr.Conn.LocalAddr().String()
				}, 2*time.Second, time.Millisecond)
				if mode != "reno" {
					require.GreaterOrEqual(t, clients.Load(), int64(round+2), "client must recreate selected controller")
					require.GreaterOrEqual(t, servers.Load(), int64(round+2), "server must recreate selected controller")
				}
			}
			require.NoError(t, s.Close())
			extra, err := io.ReadAll(s)
			require.NoError(t, err)
			require.Empty(t, extra)
			select {
			case err := <-finished:
				require.NoError(t, err)
			case <-p.ctx.Done():
				t.Fatal(context.Cause(p.ctx))
			}
			t.Logf("mode=%s exact_echo_bytes=%d native_path_changes=2 client_controllers=%d server_controllers=%d", mode, 3*(256<<10), clients.Load(), servers.Load())
		})
	}
}

func TestCC65ConcurrentSettersDuringTraffic(t *testing.T) {
	p := newCCPair(t)
	factory := ccFactoryForTest(t, "standard")
	var clients, servers atomic.Int64
	installCounted(t, p.client, factory, &clients)
	installCounted(t, p.server, factory, &servers)
	s, finished := startCCEcho(t, p)
	errorsCh := make(chan error, 64)
	var wg sync.WaitGroup
	for i := range 8 {
		conn := p.client
		if i%2 == 1 {
			conn = p.server
		}
		wg.Go(func() {
			for range 8 {
				errorsCh <- conn.SetCongestionControlFactory(factory)
			}
		})
	}
	exchangeCC(t, s, 42, 512<<10)
	wg.Wait()
	close(errorsCh)
	for err := range errorsCh {
		require.NoError(t, err)
	}
	require.NoError(t, s.Close())
	extra, err := io.ReadAll(s)
	require.NoError(t, err)
	require.True(t, bytes.Equal(extra, []byte{}))
	select {
	case err := <-finished:
		require.NoError(t, err)
	case <-p.ctx.Done():
		t.Fatal(context.Cause(p.ctx))
	}
}

func TestCC65MigrationFactoryFailureClosesConnection(t *testing.T) {
	for _, side := range []string{"client", "server"} {
		t.Run(side, func(t *testing.T) {
			p := newCCPair(t)
			factory := ccFactoryForTest(t, "brutal")
			conn := p.client
			if side == "server" {
				conn = p.server
			}
			var calls atomic.Int64
			require.NoError(t, conn.SetCongestionControlFactory(func(size congestion.ByteCount) (congestion.CongestionControl, error) {
				if calls.Add(1) > 1 {
					return nil, errors.New("intentional migration factory failure")
				}
				return factory(size)
			}))
			s, _ := startCCEcho(t, p)
			exchangeCC(t, s, 0, 4096)
			path, err := p.client.AddPath(p.second)
			require.NoError(t, err)
			require.NoError(t, path.Probe(p.ctx))
			require.NoError(t, path.Switch())
			_, _ = s.Write([]byte("trigger non-probing packet on new path"))
			select {
			case <-conn.Context().Done():
			case <-time.After(3 * time.Second):
				t.Fatal("factory failure did not close the connection")
			}
			require.Equal(t, int64(2), calls.Load())
		})
	}
}
