// Package congestion adapts the pinned Hysteria algorithms to the experimental
// factory API on quic-go v0.65. Algorithm files are unchanged except imports;
// this glue is specific to PROTO-X and is not copied from Hysteria unchanged.
package congestion

import (
	"github.com/quic-go/quic-go/congestion"
	"proto-x/internal/hycc/bbr"
	"proto-x/internal/hycc/brutal"
)

func BBRFactory(profile string) (congestion.Factory, error) {
	p, err := bbr.ParseProfile(profile)
	if err != nil {
		return nil, err
	}
	return func(size congestion.ByteCount) (congestion.CongestionControl, error) {
		return bbr.NewBbrSender(bbr.DefaultClock{}, size, p), nil
	}, nil
}

func BrutalFactory(tx uint64, disableLossCompensation bool) congestion.Factory {
	return func(congestion.ByteCount) (congestion.CongestionControl, error) {
		return brutal.NewBrutalSender(tx, disableLossCompensation), nil
	}
}
