#!/usr/bin/env python3
"""Recreate and verify the isolated quic-go v0.65 CC extension.

Only the explicitly named dependency checkout may be created or patched.
Existing changes that do not match the recorded patch are refused.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(checkout: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(checkout), *args], text=True)


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=root / ".local/quic-go-v0.65.0")
    args = parser.parse_args()
    checkout = args.directory.resolve()
    manifest = json.loads((root / "docs/research/cc65-evidence/dependency-manifest.json").read_text())
    patch = root / manifest["patch"]
    if sha256(patch) != manifest["patch_sha256"]:
        raise SystemExit("dependency patch checksum mismatch")
    if not checkout.exists():
        checkout.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(["git", "clone", "--depth", "1", "--branch", manifest["tag"],
                        manifest["repository"], str(checkout)], check=True)
    if not (checkout / ".git").exists():
        raise SystemExit("dependency directory is not a Git checkout")
    if git(checkout, "rev-parse", "HEAD").strip() != manifest["base_commit"]:
        raise SystemExit("dependency checkout is at a different revision")
    changed = set(filter(None, git(checkout, "diff", "--name-only", "-z", "HEAD").split("\0")))
    untracked = set(filter(None, git(checkout, "ls-files", "--others", "--exclude-standard", "-z").split("\0")))
    expected = manifest["patched_file_sha256"]
    if changed or untracked:
        if not (changed | untracked).issubset(expected):
            raise SystemExit("refusing unrelated changes in dependency checkout")
        if not all((checkout / p).is_file() and sha256(checkout / p) == digest for p, digest in expected.items()):
            raise SystemExit("existing dependency changes differ from the recorded extension")
        print("Dependency already matches the recorded extension.")
        return
    subprocess.run(["git", "-C", str(checkout), "apply", "--check", str(patch)], check=True)
    subprocess.run(["git", "-C", str(checkout), "apply", str(patch)], check=True)
    for path, expected_hash in expected.items():
        if sha256(checkout / path) != expected_hash:
            raise SystemExit(f"patched source checksum mismatch: {path}")
    print(f"Prepared {checkout} at {manifest['base_commit']} with verified CC patch.")


if __name__ == "__main__":
    main()
