module proto-x

go 1.26.0

require (
	github.com/quic-go/quic-go v0.65.0
	github.com/stretchr/testify v1.12.1
)

require go.yaml.in/yaml/v3 v3.0.5 // indirect

require (
	golang.org/x/crypto v0.54.0 // indirect
	golang.org/x/exp v0.0.0-20250711185948-6ae5c78190dc
	golang.org/x/net v0.56.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
)

replace github.com/quic-go/quic-go => ./.local/quic-go-v0.65.0
