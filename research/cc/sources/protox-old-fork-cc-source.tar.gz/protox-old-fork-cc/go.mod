module proto-x

go 1.26.0

require (
	github.com/apernet/quic-go v0.63.1-0.20261004180939-a10df75c260c
	github.com/stretchr/testify v1.12.1
	golang.org/x/exp v0.0.0-20250711185948-6ae5c78190dc
)

require (
	github.com/andybalholm/brotli v1.1.0 // indirect
	github.com/klauspost/compress v1.17.9 // indirect
	github.com/refraction-networking/utls v1.8.2 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/crypto v0.54.0 // indirect
	golang.org/x/net v0.57.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
)
