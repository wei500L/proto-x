package session

import (
	"bytes"
	"context"
	"io"
	"testing"

	"proto-x/internal/carrier"
	"proto-x/internal/wire"
)

func hintFlow(t *testing.T) *Flow {
	t.Helper()
	s := New("copy-test", false, testConfig())
	t.Cleanup(func() { s.Close(context.Canceled) })
	f := newFlow(s, 1, "example.test:443")
	f.opened = true
	return f
}

func TestSparseCopyDeliveredOnceAcrossOriginalOverlap(t *testing.T) {
	f := hintFlow(t)
	for _, frame := range []wire.Frame{
		{Kind: wire.Data, ID: 1, Offset: 0, Payload: []byte("abc"), Unreliable: true},
		{Kind: wire.Data, ID: 1, Offset: 0, Payload: []byte("abcde")},
		{Kind: wire.Data, ID: 1, Offset: 3, Payload: []byte("de"), Unreliable: true},
		{Kind: wire.Fin, ID: 1, Offset: 5},
	} {
		if err := f.receive(frame); err != nil {
			t.Fatal(err)
		}
	}
	got, err := io.ReadAll(f)
	if err != nil || !bytes.Equal(got, []byte("abcde")) {
		t.Fatalf("reliable stream changed: %q %v", got, err)
	}
	if f.s.HintDelivered.Load() != 3 || f.s.DuplicateBytes.Load() != 5 {
		t.Fatalf("incorrect delivery accounting: hinted=%d duplicates=%d", f.s.HintDelivered.Load(), f.s.DuplicateBytes.Load())
	}
}

func TestOptionalCopyCannotAdvanceAcrossGapOrMutateControlState(t *testing.T) {
	f := hintFlow(t)
	frames := []wire.Frame{
		{Kind: wire.Opened, ID: 1, Offset: 0, Limit: 999999, Unreliable: true},
		{Kind: wire.Fin, ID: 1, Offset: 0, Unreliable: true},
		{Kind: wire.Reset, ID: 1, Unreliable: true},
		{Kind: wire.Data, ID: 1, Offset: 3, Payload: []byte("def"), Unreliable: true},
		{Kind: wire.Data, ID: 1, Offset: ^uint64(0), Payload: []byte("overflow"), Unreliable: true},
		{Kind: wire.Data, ID: 1, Offset: 0, Payload: make([]byte, carrier.MaxHintPayload+1), Unreliable: true},
	}
	for _, frame := range frames {
		if err := f.receive(frame); err != nil {
			t.Fatal(err)
		}
	}
	if f.rxNext != 0 || f.rxEOF || f.err != nil || len(f.rxBuf) != 0 || f.s.HintDelivered.Load() != 0 {
		t.Fatal("optional input mutated reliable stream state")
	}
	// The ordinary reliable path still fills the discarded copy's gap.
	if err := f.receive(wire.Frame{Kind: wire.Data, ID: 1, Payload: []byte("abcdef")}); err != nil {
		t.Fatal(err)
	}
	got := make([]byte, 6)
	if _, err := io.ReadFull(f, got); err != nil || string(got) != "abcdef" {
		t.Fatalf("original data missing: %q %v", got, err)
	}
}

func TestOptionalCopyRespectsConsumedWindowAndFinishedStream(t *testing.T) {
	f := hintFlow(t)
	f.rxNext = uint64(f.s.cfg.Window)
	if err := f.receive(wire.Frame{Kind: wire.Data, ID: 1, Offset: f.rxNext, Payload: []byte("x"), Unreliable: true}); err != nil {
		t.Fatal(err)
	}
	if len(f.rxBuf) != 0 {
		t.Fatal("copy extended a full receive window")
	}
	f.rxConsumed = f.rxNext
	f.rxEOF = true
	if err := f.receive(wire.Frame{Kind: wire.Data, ID: 1, Offset: f.rxNext, Payload: []byte("x"), Unreliable: true}); err != nil {
		t.Fatal(err)
	}
	if len(f.rxBuf) != 0 {
		t.Fatal("copy appended after FIN")
	}
}
