package session

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"proto-x/internal/carrier"
	"proto-x/internal/wire"
)

// This is a session-state test, not a QUIC packet-loss or cryptography test.
// The first reliable DATA is accepted by a test-only record filter but withheld
// from the receiver. Its prefix is injected at the receiving Flow boundary with
// the same Unreliable metadata that a validated QUIC DATAGRAM would carry.
// The ACK uses the normal record path; no ACK or sender offset is injected.
func TestHintAcknowledgedBeforeOriginalSurvivesCarrierReplacement(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()

	const copied = carrier.MaxHintPayload
	initial := deterministicBytes(wire.DataPayload, 610)
	tail := deterministicBytes((64<<10)+113, 611)
	request := append(append([]byte(nil), initial...), tail...)
	reply := deterministicBytes((32<<10)+47, 612)
	originPrefix := make(chan error, 1)
	originDone := make(chan error, 1)
	o := listenOrigin(t, func(c *net.TCPConn) {
		prefix := make([]byte, copied)
		_, err := io.ReadFull(c, prefix)
		if err == nil && !bytes.Equal(prefix, initial[:copied]) {
			err = errors.New("origin did not receive the exact hinted prefix")
		}
		select {
		case originPrefix <- err:
		case <-ctx.Done():
			return
		}
		if err == nil {
			var rest []byte
			// A reply is deliberately impossible until the client half-closes.
			rest, err = io.ReadAll(c)
			body := append(prefix, rest...)
			if err == nil && !bytes.Equal(body, request) {
				err = fmt.Errorf("origin bytes changed across resume: got %d, want %d", len(body), len(request))
			}
		}
		if err == nil {
			_, err = io.Copy(c, bytes.NewReader(reply))
		}
		if err == nil {
			err = c.CloseWrite()
		}
		select {
		case originDone <- err:
		case <-ctx.Done():
		}
	})

	cfg := testConfig()
	cfg.SparseRedundancy = true
	cfg.DeadAfter = 5 * time.Second
	cfg.ResumeTTL = 10 * time.Second
	p := newMemorySessions(t, cfg)
	p.drop()

	// AcceptTLS only wraps a net.Pipe here; it does not run TLS. A single
	// Write from wire.Write contains a complete record in this fixture.
	left, right := net.Pipe()
	captured := make(chan wire.Frame, 1)
	var held, forwarded atomic.Int64
	filtered := &filteredWriteConn{Conn: left, drop: func(record wire.Frame) bool {
		if record.Kind != wire.Data {
			return false
		}
		if held.CompareAndSwap(0, 1) {
			captured <- record
			return true
		}
		forwarded.Add(int64(len(record.Payload)))
		return false
	}}
	p.cl, p.sl = carrier.AcceptTLS(filtered), carrier.AcceptTLS(right)
	if err := p.server.Attach(p.sl); err != nil {
		t.Fatal(err)
	}
	if err := p.client.Attach(p.cl); err != nil {
		t.Fatal(err)
	}
	f := openTestFlow(t, p.client, o.address)
	p.server.mu.Lock()
	serverFlow := p.server.flows[f.id]
	p.server.mu.Unlock()
	if serverFlow == nil {
		t.Fatal("opened flow has no server state")
	}
	serverFlow.mu.Lock()
	originalSocket := serverFlow.socket
	serverFlow.mu.Unlock()
	if originalSocket == nil {
		t.Fatal("opened flow has no target socket")
	}

	if n, err := f.Write(initial); err != nil || n != len(initial) {
		t.Fatalf("initial write: n=%d err=%v", n, err)
	}
	original := hintResumeWait(t, ctx, "withheld original DATA", captured)
	if original.ID != f.id || original.Offset != 0 || !bytes.Equal(original.Payload, initial) {
		t.Fatalf("unexpected withheld record: id=%d offset=%d bytes=%d", original.ID, original.Offset, len(original.Payload))
	}

	acknowledged := hintResumeObserveACK(f, copied)
	copyFrame := wire.Frame{Kind: wire.Data, ID: f.id, Offset: 0,
		Payload: append([]byte(nil), original.Payload[:copied]...), Unreliable: true}
	if err := serverFlow.receive(copyFrame); err != nil {
		t.Fatal(err)
	}
	if err := hintResumeWait(t, ctx, "target receipt of hinted bytes", originPrefix); err != nil {
		t.Fatal(err)
	}
	ack := hintResumeWait(t, ctx, "normal ACK of hinted bytes", acknowledged)
	if ack.err != nil || ack.base != copied || ack.end != uint64(len(initial)) ||
		!bytes.Equal(ack.retained, initial[copied:]) {
		t.Fatalf("hint ACK did not trim only the delivered prefix: base=%d end=%d retained=%d err=%v",
			ack.base, ack.end, len(ack.retained), ack.err)
	}
	if got := p.server.HintDelivered.Load(); got != copied {
		t.Fatalf("test did not deliver its hint: got %d bytes, want %d", got, copied)
	}
	if held.Load() != 1 || forwarded.Load() != 0 {
		t.Fatalf("original escaped before interruption: held=%d forwarded=%d", held.Load(), forwarded.Load())
	}
	select {
	case err := <-originDone:
		t.Fatalf("target finished before application half-close: %v", err)
	default:
	}

	// At this barrier the target consumed the hint and the sender processed
	// its ACK, but no original DATA reached the receiving session.
	p.drop()
	left, right = net.Pipe()
	replayed := make(chan wire.Frame, 1)
	var firstReplay atomic.Bool
	observed := &filteredWriteConn{Conn: left, drop: func(record wire.Frame) bool {
		if record.Kind == wire.Data && firstReplay.CompareAndSwap(false, true) {
			replayed <- record
		}
		return false
	}}
	p.cl, p.sl = carrier.AcceptTLS(observed), carrier.AcceptTLS(right)
	if err := p.server.Attach(p.sl); err != nil {
		t.Fatal(err)
	}
	if err := p.client.Attach(p.cl); err != nil {
		t.Fatal(err)
	}
	resumed := hintResumeWait(t, ctx, "automatic replay after hint ACK", replayed)
	if resumed.ID != f.id || resumed.Offset != copied || !bytes.Equal(resumed.Payload, initial[copied:]) {
		t.Fatalf("resume ignored acknowledged hint offset: id=%d offset=%d bytes=%d", resumed.ID, resumed.Offset, len(resumed.Payload))
	}

	// Replay the whole withheld original after the automatic suffix. This is
	// explicit record-layer duplicate injection, not a claim that old QUIC
	// packets cross connection identities. Link.Send serializes it after the
	// observed DATA, and the receiver must not deliver the overlap again.
	if err := p.cl.Send(original); err != nil {
		t.Fatal(err)
	}
	writeDone := make(chan error, 1)
	readDone := make(chan error, 1)
	go func() {
		n, err := f.Write(tail)
		if err == nil && n != len(tail) {
			err = io.ErrShortWrite
		}
		if err == nil {
			err = f.CloseWrite()
		}
		writeDone <- err
	}()
	go func() {
		body, err := io.ReadAll(f)
		if err == nil && !bytes.Equal(body, reply) {
			err = fmt.Errorf("reply changed or EOF was premature: got %d bytes, want %d", len(body), len(reply))
		}
		readDone <- err
	}()
	for name, ch := range map[string]<-chan error{"writer half-close": writeDone, "reply and EOF": readDone, "origin completion": originDone} {
		if err := hintResumeWait(t, ctx, name, ch); err != nil {
			t.Fatalf("%s: %v", name, err)
		}
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	hintResumeWait(t, ctx, "client flow retirement", f.done)
	hintResumeWait(t, ctx, "server flow retirement", serverFlow.done)
	serverFlow.mu.Lock()
	sameSocket := serverFlow.socket == originalSocket
	serverErr := serverFlow.err
	serverClean := serverFlow.txFinAck && serverFlow.rxReadEOF
	serverFlow.mu.Unlock()
	f.mu.Lock()
	clientErr := f.err
	clientClean := f.txFinAck && f.rxReadEOF
	f.mu.Unlock()
	if !sameSocket || p.dials.Load() != 1 || o.count.Load() != 1 {
		t.Fatalf("resume recreated target: same=%v dials=%d accepts=%d", sameSocket, p.dials.Load(), o.count.Load())
	}
	if clientErr != nil || serverErr != nil || !clientClean || !serverClean {
		t.Fatalf("half-close ended in reset or incomplete FIN: client=%v/%v server=%v/%v", clientErr, clientClean, serverErr, serverClean)
	}
	if p.server.HintDelivered.Load() != copied || p.server.DuplicateBytes.Load() < uint64(len(original.Payload)) {
		t.Fatalf("hint/overlap path not exercised: hinted=%d duplicates=%d", p.server.HintDelivered.Load(), p.server.DuplicateBytes.Load())
	}
}

type hintResumeACK struct {
	base, end uint64
	retained  []byte
	err       error
}

// Observe the sender's existing ACK condition variable without mutating its
// offsets. Test cleanup closes the session and wakes this waiter on failure.
func hintResumeObserveACK(f *Flow, want uint64) <-chan hintResumeACK {
	result := make(chan hintResumeACK, 1)
	go func() {
		f.mu.Lock()
		for f.txBase < want && f.err == nil {
			f.cond.Wait()
		}
		state := hintResumeACK{base: f.txBase, end: f.txEnd, retained: append([]byte(nil), f.txBuf...), err: f.err}
		f.mu.Unlock()
		result <- state
	}()
	return result
}

func hintResumeWait[T any](t *testing.T, ctx context.Context, description string, ch <-chan T) T {
	t.Helper()
	select {
	case value := <-ch:
		return value
	case <-ctx.Done():
		t.Fatalf("waiting for %s: %v", description, ctx.Err())
		var zero T
		return zero
	}
}
