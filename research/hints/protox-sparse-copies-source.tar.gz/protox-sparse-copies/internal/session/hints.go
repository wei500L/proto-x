package session

import (
	"context"
	"time"

	"proto-x/internal/carrier"
	"proto-x/internal/scheduler"
	"proto-x/internal/wire"
)

// Sparse copies are delayed to reduce sharing the original packet's fate.
// QUIC remains free to coalesce them under congestion; there is no assertion
// that these are independent losses. The packet-level lab must measure that.
const hintDelay = 8 * time.Millisecond

// This is a PRE-SUBMISSION age limit. quic-go's SendDatagram queue has no expiry
// API and may block when full; congestion can delay an accepted copy further.
const hintSubmitWindow = 40 * time.Millisecond

type hint struct {
	flow       *Flow
	link       *carrier.Link
	generation uint64
	frame      wire.Frame
	ready      time.Time
	expires    time.Time
}

func (s *Session) queueHints(f *Flow, l *carrier.Link, gen uint64, p wire.Frame) {
	now := time.Now()
	for at := 0; at < len(p.Payload); {
		n := min(carrier.MaxHintPayload, len(p.Payload)-at)
		copyFrame := wire.Frame{Kind: wire.Data, ID: p.ID, Offset: p.Offset + uint64(at),
			Payload: append([]byte(nil), p.Payload[at:at+n]...)}
		h := hint{flow: f, link: l, generation: gen, frame: copyFrame,
			ready: now.Add(hintDelay), expires: now.Add(hintSubmitWindow)}
		select {
		case s.hints <- h:
		default:
			s.HintSkipped.Add(1)
		}
		at += n
	}
}

func (s *Session) sendHints() {
	// Copies consume the SAME total paced budget as original data. This second
	// budget also limits them to <=10% of configured rate (max64KiB/s), before
	// headers below QUIC. With shaping off, the explicit64KiB/s cap remains.
	copyRate := 64.0 * 1024
	if s.cfg.Rate > 0 {
		copyRate = min(copyRate, s.cfg.Rate*0.1)
	}
	budget := scheduler.New(s.ctx, copyRate, false, false)
	for {
		select {
		case <-s.ctx.Done():
			return
		case h := <-s.hints:
			if !s.hintUseful(h) {
				s.HintSkipped.Add(1)
				continue
			}
			t := time.NewTimer(max(0, time.Until(h.ready)))
			select {
			case <-s.ctx.Done():
				t.Stop()
				return
			case <-t.C:
			}
			if !s.hintUseful(h) {
				s.HintSkipped.Add(1)
				continue
			}
			ctx, cancel := context.WithDeadline(s.ctx, h.expires)
			cost := wire.HeaderSize + len(h.frame.Payload) + 64
			err := budget.Acquire(ctx, cost, false)
			if err == nil && !s.hintUseful(h) {
				cancel()
				s.HintSkipped.Add(1)
				continue
			}
			if err == nil {
				err = s.budget.Acquire(ctx, cost, true)
			}
			useful := err == nil && s.hintUseful(h)
			// Once handed to QUIC, congestion may keep a copy in its internal
			// bounded queue beyond expires. Byte correctness still comes from
			// offsets, but this is not a hard wire-deadline guarantee.
			if useful && h.link.SendHint(h.frame) {
				s.HintSent.Add(1)
			} else {
				s.HintSkipped.Add(1)
			}
			cancel()
		}
	}
}

func (s *Session) hintUseful(h hint) bool {
	if !time.Now().Before(h.expires) {
		return false
	}
	l, gen, _ := s.Current()
	if l != h.link || gen != h.generation {
		return false
	}
	h.flow.mu.Lock()
	defer h.flow.mu.Unlock()
	select {
	case <-h.flow.done:
		return false
	default:
	}
	return h.flow.err == nil && h.flow.txBase < h.frame.Offset+uint64(len(h.frame.Payload))
}
