package carrier

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"math/big"
	"testing"
	"time"

	quic "github.com/quic-go/quic-go"
	"proto-x/internal/wire"
)

func TestQUICAuthenticatedDatagramCarriesOnlyOptionalDATA(t *testing.T) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	template := &x509.Certificate{SerialNumber: big.NewInt(1), NotBefore: time.Now().Add(-time.Hour),
		NotAfter: time.Now().Add(time.Hour), DNSNames: []string{"proto-x.local"},
		KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	der, err := x509.CreateCertificate(rand.Reader, template, template, &key.PublicKey, key)
	if err != nil {
		t.Fatal(err)
	}
	listener, err := quic.ListenAddr("127.0.0.1:0", TLSConfig(tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key}), QUICConfig())
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	server := make(chan *Link, 1)
	serverErr := make(chan error, 1)
	go func() {
		c, err := listener.Accept(ctx)
		if err != nil {
			serverErr <- err
			return
		}
		l, err := AcceptQUIC(ctx, c)
		if err == nil {
			l.SetHandshakeDeadline(time.Now().Add(time.Second))
			_, err = l.HandshakeRead()
		}
		if err != nil {
			serverErr <- err
			return
		}
		l.SetHandshakeDeadline(time.Time{})
		l.Start()
		server <- l
	}()
	pin := sha256.Sum256(der)
	tc, err := ClientTLS(hex.EncodeToString(pin[:]), "proto-x.local")
	if err != nil {
		t.Fatal(err)
	}
	client, err := Dial(ctx, "quic", listener.Addr().String(), tc)
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	if err := client.HandshakeWrite(wire.Frame{Kind: wire.Hello, Payload: []byte("fixture")}); err != nil {
		t.Fatal(err)
	}
	var peer *Link
	select {
	case peer = <-server:
	case err := <-serverErr:
		t.Fatal(err)
	case <-ctx.Done():
		t.Fatal(ctx.Err())
	}
	defer peer.Close()
	client.Start()
	var malformed bytes.Buffer
	if err := wire.Write(&malformed, wire.Frame{Kind: wire.Open, ID: 1, Payload: []byte("forbidden.test:80")}); err != nil {
		t.Fatal(err)
	}
	if err := client.QUIC.SendDatagram(malformed.Bytes()); err != nil {
		t.Fatal(err)
	}
	if client.SendHint(wire.Frame{Kind: wire.Reset, ID: 1}) {
		t.Fatal("control record sent as optional data")
	}
	if !client.SendHint(wire.Frame{Kind: wire.Data, ID: 1, Offset: 100, Payload: []byte("small response")}) {
		t.Fatal("valid datagram rejected")
	}
	f, err := peer.NextFrame(ctx)
	if err != nil {
		t.Fatal(err)
	}
	if !f.Unreliable || f.Kind != wire.Data || f.Offset != 100 || string(f.Payload) != "small response" {
		t.Fatalf("wrong datagram record %+v", f)
	}
}

func TestCopyQueueCannotDelayAlreadyQueuedReliableControl(t *testing.T) {
	l := newLink("fixture", nil)
	defer l.cancel()
	for i := 0; i < cap(l.hints); i++ {
		l.hints <- wire.Frame{Kind: wire.Data, ID: 1, Unreliable: true, Payload: []byte("x")}
	}
	l.in <- wire.Frame{Kind: wire.Ack, ID: 1, Offset: 100}
	f, err := l.NextFrame(context.Background())
	if err != nil || f.Kind != wire.Ack || f.Unreliable {
		t.Fatalf("full optional queue hid reliable control: %+v %v", f, err)
	}
}
